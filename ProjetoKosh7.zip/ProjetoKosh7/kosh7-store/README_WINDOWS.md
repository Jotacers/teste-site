# 🚀 Guia Rápido - Kosh7 Store no Windows

## ⚡ Início Rápido (3 Cliques)

### Opção 1: Automático (Recomendado)
1. **Duplo clique** em `install-and-run.bat`
2. Aguarde a instalação (pode levar 2-3 minutos)
3. O navegador abrirá automaticamente em `http://localhost:3000`

### Opção 2: Desenvolvimento
1. **Duplo clique** em `start-dev.bat`
2. O site abrirá em `http://localhost:3000`
3. Pressione `Ctrl+C` para parar

---

## 📋 Pré-requisitos

### ✅ Verificar se tem Node.js

Abra o **Prompt de Comando** (Win+R, digite `cmd`, Enter) e execute:

```cmd
node --version
npm --version
```

Se aparecer versões, está tudo certo! ✅

### ❌ Se não tiver Node.js

1. Acesse: https://nodejs.org/
2. Baixe a versão **LTS** (recomendado)
3. Execute o instalador
4. Escolha "Add to PATH" durante a instalação
5. Reinicie o computador

---

## 📁 Estrutura de Arquivos

```
kosh7-store/
├── install-and-run.bat      ← Clique para iniciar (setup completo)
├── start-dev.bat            ← Clique para iniciar (desenvolvimento)
├── start.bat                ← Clique para iniciar (produção)
├── package.json             ← Dependências do projeto
├── client/                  ← Frontend React
├── server/                  ← Backend Node.js
├── drizzle/                 ← Banco de dados
├── .env.example             ← Variáveis de ambiente
└── README.md                ← Documentação completa
```

---

## 🎯 Como Usar

### 1️⃣ Primeira Vez (Setup Completo)

```cmd
install-and-run.bat
```

Isso vai:
- ✅ Instalar todas as dependências
- ✅ Compilar o frontend
- ✅ Iniciar o servidor
- ✅ Abrir o navegador automaticamente

### 2️⃣ Próximas Vezes (Desenvolvimento)

```cmd
start-dev.bat
```

Isso vai:
- ✅ Iniciar o servidor em modo desenvolvimento
- ✅ Abrir o navegador automaticamente
- ✅ Recarregar automaticamente ao salvar arquivos

### 3️⃣ Parar o Servidor

Pressione `Ctrl+C` na janela do Prompt de Comando

---

## 🔧 Configuração Manual (Opcional)

Se preferir fazer manualmente no Prompt de Comando:

### 1. Instalar Dependências
```cmd
npm install
```

### 2. Compilar Frontend
```cmd
npm run build
```

### 3. Iniciar em Desenvolvimento
```cmd
npm run dev
```

### 4. Abrir no Navegador
```cmd
http://localhost:3000
```

---

## 🌐 Acessar o Site

Após iniciar, o site estará disponível em:

- **Local**: http://localhost:3000
- **Rede**: http://seu-ip-local:3000

---

## 📝 Variáveis de Ambiente

Se precisar configurar credenciais (Stripe, Discord, etc.):

1. Abra o arquivo `.env` com um editor de texto
2. Preencha com suas credenciais
3. Salve o arquivo
4. Reinicie o servidor

---

## 🆘 Troubleshooting

### Erro: "Node.js não encontrado"
- Instale Node.js: https://nodejs.org/
- Reinicie o computador após instalar

### Erro: "Port 3000 already in use"
- Outro programa está usando a porta 3000
- Opção 1: Feche o outro programa
- Opção 2: Mude a porta no arquivo `.env` (PORT=3001)

### Erro: "npm: command not found"
- Node.js não foi instalado corretamente
- Reinstale Node.js e escolha "Add to PATH"

### O site não carrega
- Aguarde 10 segundos (primeiro carregamento é mais lento)
- Pressione F5 para recarregar
- Verifique o console (F12) para erros

---

## 📦 Arquivos .bat Explicados

### `install-and-run.bat`
- **Uso**: Primeira vez ou setup completo
- **O que faz**: Instala dependências, compila e inicia
- **Tempo**: 2-3 minutos

### `start-dev.bat`
- **Uso**: Desenvolvimento diário
- **O que faz**: Inicia servidor com hot-reload
- **Tempo**: 10-15 segundos

### `start.bat`
- **Uso**: Produção/testes finais
- **O que faz**: Inicia servidor otimizado
- **Tempo**: 5-10 segundos

---

## 💡 Dicas

1. **Manter aberto**: Deixe o Prompt de Comando aberto enquanto trabalha
2. **Hot-reload**: Salve um arquivo e o site recarrega automaticamente
3. **Logs**: Veja os logs no Prompt de Comando para debug
4. **Ctrl+C**: Pressione para parar o servidor com segurança

---

## 🚀 Deploy na Hostinger

Quando estiver pronto para colocar online:

1. Leia o arquivo `HOSTINGER_DEPLOYMENT_GUIDE.md`
2. Siga as instruções passo-a-passo
3. Seu site estará online em minutos!

---

## 📞 Suporte

Se encontrar problemas:

1. Verifique se Node.js está instalado: `node --version`
2. Verifique os logs no Prompt de Comando
3. Tente deletar `node_modules` e rodar `npm install` novamente
4. Reinicie o computador

---

**Pronto! Seu site Kosh7 Store está rodando! 🎉**

Acesse: http://localhost:3000
