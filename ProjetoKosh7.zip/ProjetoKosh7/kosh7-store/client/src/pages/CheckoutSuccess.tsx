import { useEffect, useState } from "react";
import { CheckCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CheckoutSuccess() {
  const [isLoading, setIsLoading] = useState(true);
  const [orderData, setOrderData] = useState<any>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const sessionId = params.get("session_id");

    if (!sessionId) {
      setError("Session ID não encontrado");
      setIsLoading(false);
      return;
    }

    // Confirmar pagamento com o backend
    fetch("/api/checkout/confirm", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ sessionId }),
      credentials: "include",
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.error) {
          setError(data.error);
        } else {
          setOrderData(data);
        }
      })
      .catch((err) => setError(err.message))
      .finally(() => setIsLoading(false));
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-white mx-auto mb-4" />
          <p className="text-white">Confirmando pagamento...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-full max-w-md p-6 bg-white rounded-lg shadow-lg text-center">
          <div className="text-red-600 text-6xl mb-4">✕</div>
          <h1 className="text-2xl font-bold text-black mb-2">Erro no Pagamento</h1>
          <p className="text-gray-600 mb-6">{error}</p>
          <Button
            onClick={() => (window.location.href = "/")}
            className="w-full bg-black hover:bg-gray-800 text-white"
          >
            Voltar para Home
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="w-full max-w-md p-6 bg-white rounded-lg shadow-lg text-center">
        <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
        <h1 className="text-2xl font-bold text-black mb-2">Pagamento Confirmado!</h1>
        <p className="text-gray-600 mb-6">
          Obrigado pela sua compra. Seu pedido foi processado com sucesso.
        </p>

        {orderData && (
          <div className="mb-6 p-4 bg-gray-50 rounded-lg text-left">
            <p className="text-sm text-gray-700 mb-2">
              <strong>ID do Pedido:</strong> #{orderData.orderId}
            </p>
            <p className="text-sm text-gray-700 mb-2">
              <strong>Valor Total:</strong> R$ {orderData.totalAmount}
            </p>
            <p className="text-sm text-gray-700">
              <strong>Status:</strong> {orderData.status === "completed" ? "Concluído" : "Processando"}
            </p>
          </div>
        )}

        <p className="text-sm text-gray-600 mb-6">
          Um email de confirmação foi enviado para você.
        </p>

        <Button
          onClick={() => (window.location.href = "/")}
          className="w-full bg-black hover:bg-gray-800 text-white"
        >
          Voltar para Home
        </Button>
      </div>
    </div>
  );
}
