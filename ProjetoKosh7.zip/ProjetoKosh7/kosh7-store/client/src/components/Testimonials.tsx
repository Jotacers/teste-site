import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export default function Testimonials() {
  const testimonials = [
    {
      name: 'Jops',
      initials: 'JP',
      text: 'vant infinito funcionando perfeitamente com o aa emulador, equipe deu uma atenção foda.',
    },
    {
      name: 'rvl',
      initials: 'RV',
      text: 'Servico de bot lobby é incrivel! Peguei a singularidade sem trabalho algum, sem contar o atendimento que tb foi incrivel, tmjj.',
    },
    {
      name: 'sczz boss',
      initials: 'SB',
      text: 'Acabei de adquirir o Game Pass Ultimate, e chegou tudo certinhos obrigado pelo ótimo atendimento.',
    },
    {
      name: 'TetashiFX',
      initials: 'TF',
      text: 'Comprei o AA profissional e não me arrependo! Sensacional melhor que tem no mercado e o suporte sem palavras, os caras são feras, os melhores!',
    },
    {
      name: 'junior',
      initials: 'JR',
      text: 'Ghost external muito bom, xitando só de esp 30+ kills por partida, estou jogando por 6 horas seguidas.',
    },
  ];

  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const next = () => setCurrent((prev) => (prev + 1) % testimonials.length);
  const prev = () => setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  return (
    <section className="py-20">
      <div className="container">
        <div className="mb-12">
          <h2 className="text-white mb-2">Avaliações</h2>
          <p className="text-white/60">O que nossos clientes dizem</p>
        </div>

        <div className="relative">
          <div className="overflow-hidden">
            <div className="flex transition-transform duration-500" style={{ transform: `translateX(-${current * 100}%)` }}>
              {testimonials.map((testimonial, index) => (
                <div key={index} className="w-full flex-shrink-0 px-4">
                  <div className="">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-12 h-12 rounded-full bg-white/10 border border-white/20 flex items-center justify-center">
                        <span className="text-white font-bold text-sm">{testimonial.initials}</span>
                      </div>
                      <div>
                        <h4 className="text-white font-bold">{testimonial.name}</h4>
                      </div>
                    </div>
                    <p className="text-white/80 italic">"{testimonial.text}"</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Controles */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <button
              onClick={prev}
              className="p-2 rounded-full border border-white/20 text-white hover:border-white/40 transition-colors"
            >
              <ChevronLeft size={20} />
            </button>
            <div className="flex gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrent(index)}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    index === current ? 'bg-white' : 'bg-white/30'
                  }`}
                />
              ))}
            </div>
            <button
              onClick={next}
              className="p-2 rounded-full border border-white/20 text-white hover:border-white/40 transition-colors"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
