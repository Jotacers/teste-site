import { describe, it, expect, beforeEach, vi } from "vitest";
import * as auth from "./auth";
import * as db from "./db";

// Mock do módulo db
vi.mock("./db", () => ({
  getUserByEmail: vi.fn(),
  getUserByDiscordId: vi.fn(),
  upsertUser: vi.fn(),
}));

describe("Authentication", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("hashPassword", () => {
    it("should hash password with salt", () => {
      const password = "test123";
      const hash = auth.hashPassword(password);
      
      expect(hash).toContain(":");
      const [salt, hashPart] = hash.split(":");
      expect(salt).toHaveLength(32);
      expect(hashPart).toHaveLength(128);
    });

    it("should produce different hashes for same password", () => {
      const password = "test123";
      const hash1 = auth.hashPassword(password);
      const hash2 = auth.hashPassword(password);
      
      expect(hash1).not.toBe(hash2);
    });
  });

  describe("verifyPassword", () => {
    it("should verify correct password", () => {
      const password = "test123";
      const hash = auth.hashPassword(password);
      
      const isValid = auth.verifyPassword(password, hash);
      expect(isValid).toBe(true);
    });

    it("should reject incorrect password", () => {
      const password = "test123";
      const hash = auth.hashPassword(password);
      
      const isValid = auth.verifyPassword("wrongpassword", hash);
      expect(isValid).toBe(false);
    });
  });

  describe("createSessionToken", () => {
    it("should create a valid JWT token", async () => {
      const userId = 1;
      const email = "test@example.com";
      
      const token = await auth.createSessionToken(userId, email);
      
      expect(token).toBeTruthy();
      expect(typeof token).toBe("string");
      expect(token.split(".")).toHaveLength(3);
    });
  });

  describe("verifySessionToken", () => {
    it("should verify valid token", async () => {
      const userId = 1;
      const email = "test@example.com";
      
      const token = await auth.createSessionToken(userId, email);
      const session = await auth.verifySessionToken(token);
      
      expect(session).toBeTruthy();
      expect(session?.userId).toBe(userId);
      expect(session?.email).toBe(email);
    });

    it("should reject invalid token", async () => {
      const session = await auth.verifySessionToken("invalid.token.here");
      expect(session).toBeNull();
    });

    it("should reject null token", async () => {
      const session = await auth.verifySessionToken(null);
      expect(session).toBeNull();
    });

    it("should reject undefined token", async () => {
      const session = await auth.verifySessionToken(undefined);
      expect(session).toBeNull();
    });
  });

  describe("registerUser", () => {
    it("should register new user with email and password", async () => {
      const mockUser = {
        id: 1,
        email: "newuser@example.com",
        name: "New User",
        passwordHash: "hashed",
        discordId: null,
        discordUsername: null,
        discordAvatar: null,
        loginMethod: "email",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      vi.mocked(db.getUserByEmail)
        .mockResolvedValueOnce(undefined)
        .mockResolvedValueOnce(mockUser);
      vi.mocked(db.upsertUser).mockResolvedValue(undefined);

      const user = await auth.registerUser("newuser@example.com", "password123", "New User");
      
      expect(user).toBeTruthy();
      expect(user.email).toBe("newuser@example.com");
      expect(db.upsertUser).toHaveBeenCalled();
    });

    it("should reject duplicate email", async () => {
      const existingUser = {
        id: 1,
        email: "existing@example.com",
        name: "Existing",
        passwordHash: "hashed",
        discordId: null,
        discordUsername: null,
        discordAvatar: null,
        loginMethod: "email",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      vi.mocked(db.getUserByEmail).mockResolvedValue(existingUser);

      await expect(
        auth.registerUser("existing@example.com", "password123")
      ).rejects.toThrow("Email já registrado");
    });
  });

  describe("loginWithEmail", () => {
    it("should login user with correct credentials", async () => {
      const password = "password123";
      const hash = auth.hashPassword(password);
      
      const mockUser = {
        id: 1,
        email: "user@example.com",
        name: "User",
        passwordHash: hash,
        discordId: null,
        discordUsername: null,
        discordAvatar: null,
        loginMethod: "email",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      vi.mocked(db.getUserByEmail).mockResolvedValue(mockUser);
      vi.mocked(db.upsertUser).mockResolvedValue(undefined);

      const user = await auth.loginWithEmail("user@example.com", password);
      
      expect(user).toBeTruthy();
      expect(user.email).toBe("user@example.com");
    });

    it("should reject invalid password", async () => {
      const hash = auth.hashPassword("correctpassword");
      
      const mockUser = {
        id: 1,
        email: "user@example.com",
        name: "User",
        passwordHash: hash,
        discordId: null,
        discordUsername: null,
        discordAvatar: null,
        loginMethod: "email",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      vi.mocked(db.getUserByEmail).mockResolvedValue(mockUser);

      await expect(
        auth.loginWithEmail("user@example.com", "wrongpassword")
      ).rejects.toThrow("Email ou senha inválidos");
    });

    it("should reject non-existent user", async () => {
      vi.mocked(db.getUserByEmail).mockResolvedValue(undefined);

      await expect(
        auth.loginWithEmail("nonexistent@example.com", "password123")
      ).rejects.toThrow("Email ou senha inválidos");
    });
  });

  describe("loginWithDiscord", () => {
    it("should create new user from Discord", async () => {
      const mockUser = {
        id: 1,
        email: "user@discord.local",
        name: "Discord User",
        passwordHash: null,
        discordId: "123456",
        discordUsername: "discorduser",
        discordAvatar: "https://example.com/avatar.png",
        loginMethod: "discord",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      vi.mocked(db.getUserByDiscordId)
        .mockResolvedValueOnce(undefined)
        .mockResolvedValueOnce(mockUser);
      vi.mocked(db.getUserByEmail).mockResolvedValueOnce(undefined);
      vi.mocked(db.upsertUser).mockResolvedValue(undefined);

      const user = await auth.loginWithDiscord(
        "123456",
        "discorduser",
        "https://example.com/avatar.png",
        "user@discord.local",
        "Discord User"
      );

      expect(user).toBeTruthy();
      expect(user.discordId).toBe("123456");
      expect(db.upsertUser).toHaveBeenCalled();
    });

    it("should handle null Discord avatar", async () => {
      const mockUser = {
        id: 1,
        email: "user@discord.local",
        name: "Discord User",
        passwordHash: null,
        discordId: "123456",
        discordUsername: "discorduser",
        discordAvatar: null,
        loginMethod: "discord",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      vi.mocked(db.getUserByDiscordId)
        .mockResolvedValueOnce(undefined)
        .mockResolvedValueOnce(mockUser);
      vi.mocked(db.getUserByEmail).mockResolvedValueOnce(undefined);
      vi.mocked(db.upsertUser).mockResolvedValue(undefined);

      const user = await auth.loginWithDiscord(
        "123456",
        "discorduser",
        null,
        "user@discord.local"
      );

      expect(user).toBeTruthy();
      expect(user.discordAvatar).toBeNull();
    });
  });
});
