import YinYangLogo from './YinYangLogo';

export default function Hero() {
  return (
    <section className="py-20 md:py-32">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Conteúdo esquerdo */}
          <div className="flex flex-col gap-6">
            <h1 className="text-white leading-tight">
              A <span className="text-white">loja amadora</span> que busca vencer e virar a líder!
            </h1>
            <p className="text-white/70 text-lg leading-relaxed">
              A Kosh7 Store é uma loja amadora que está começando sua jornada no mercado dos jogos, buscando oferecer uma ampla variedade de serviços com preços competitivos e qualidade incomparável para se tornar a referência do mercado.
            </p>
            <div className="flex gap-4 pt-4">
              <button className="bg-white text-black px-8 py-3 rounded-full font-semibold hover:bg-white/90 transition-colors">
                Conferir ofertas
              </button>
              <button className="border border-white/30 text-white px-8 py-3 rounded-full font-semibold hover:border-white/60 hover:bg-white/5 transition-colors">
                Saiba mais
              </button>
            </div>
          </div>

          {/* Yin-yang animado direito */}
          <div className="flex justify-center md:justify-end">
            <div className="p-8">
              <YinYangLogo />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
