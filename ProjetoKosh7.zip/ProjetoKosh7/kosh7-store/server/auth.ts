import { SignJWT, jwtVerify } from "jose";
import { ENV } from "./_core/env";
import * as db from "./db";
import type { User } from "../drizzle/schema";
import crypto from "crypto";

const COOKIE_NAME = "kosh7_session";
const ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1000;

export type SessionPayload = {
  userId: number;
  email: string;
};

/**
 * Hash de senha usando bcrypt-like (simplificado para produção usar bcrypt real)
 */
export function hashPassword(password: string): string {
  // Em produção, usar bcrypt real: npm install bcrypt
  // Por enquanto usar PBKDF2
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, "sha512").toString("hex");
  return `${salt}:${hash}`;
}

/**
 * Verificar senha
 */
export function verifyPassword(password: string, hash: string): boolean {
  const [salt, storedHash] = hash.split(":");
  const computedHash = crypto.pbkdf2Sync(password, salt, 100000, 64, "sha512").toString("hex");
  return computedHash === storedHash;
}

/**
 * Criar token de sessão JWT
 */
export async function createSessionToken(
  userId: number,
  email: string,
  options: { expiresInMs?: number } = {}
): Promise<string> {
  const issuedAt = Date.now();
  const expiresInMs = options.expiresInMs ?? ONE_YEAR_MS;
  const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1000);
  const secretKey = new TextEncoder().encode(ENV.jwtSecret);

  return new SignJWT({
    userId,
    email,
  })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setExpirationTime(expirationSeconds)
    .sign(secretKey);
}

/**
 * Verificar token de sessão JWT
 */
export async function verifySessionToken(
  token: string | undefined | null
): Promise<SessionPayload | null> {
  if (!token) {
    return null;
  }

  try {
    const secretKey = new TextEncoder().encode(ENV.jwtSecret);
    const { payload } = await jwtVerify(token, secretKey, {
      algorithms: ["HS256"],
    });

    const { userId, email } = payload as Record<string, unknown>;

    if (typeof userId !== "number" || typeof email !== "string") {
      return null;
    }

    return { userId, email };
  } catch (error) {
    console.warn("[Auth] Session verification failed", String(error));
    return null;
  }
}

/**
 * Registrar novo usuário com email e senha
 */
export async function registerUser(
  email: string,
  password: string,
  name?: string
): Promise<User> {
  // Verificar se usuário já existe
  const existingUser = await db.getUserByEmail(email);
  if (existingUser) {
    throw new Error("Email já registrado");
  }

  // Hash da senha
  const passwordHash = hashPassword(password);

  // Criar usuário
  await db.upsertUser({
    email,
    name: name || null,
    passwordHash,
    loginMethod: "email",
    lastSignedIn: new Date(),
  });

  // Buscar usuário criado
  const user = await db.getUserByEmail(email);
  if (!user) {
    throw new Error("Falha ao criar usuário");
  }

  return user;
}

/**
 * Login com email e senha
 */
export async function loginWithEmail(
  email: string,
  password: string
): Promise<User> {
  const user = await db.getUserByEmail(email);
  if (!user) {
    throw new Error("Email ou senha inválidos");
  }

  if (!user.passwordHash) {
    throw new Error("Este usuário não tem senha configurada");
  }

  if (!verifyPassword(password, user.passwordHash)) {
    throw new Error("Email ou senha inválidos");
  }

  // Atualizar lastSignedIn
  await db.upsertUser({
    email,
    lastSignedIn: new Date(),
  });

  return user;
}

/**
 * Login/Registrar com Discord OAuth
 */
export async function loginWithDiscord(
  discordId: string,
  discordUsername: string,
  discordAvatar: string | null,
  email: string,
  name?: string
): Promise<User> {
  // Verificar se usuário já existe por Discord ID
  let user = await db.getUserByDiscordId(discordId);

  if (user) {
    // Atualizar dados do Discord
    await db.upsertUser({
      email: user.email,
      discordId,
      discordUsername,
      discordAvatar,
      loginMethod: "discord",
      lastSignedIn: new Date(),
    });
  } else {
    // Verificar se email já existe
    user = await db.getUserByEmail(email);

    if (user) {
      // Vincular Discord ao usuário existente
      await db.upsertUser({
        email,
        discordId,
        discordUsername,
        discordAvatar,
        loginMethod: "discord",
        lastSignedIn: new Date(),
      });
    } else {
      // Criar novo usuário
      await db.upsertUser({
        email,
        name: name || discordUsername,
        discordId,
        discordUsername,
        discordAvatar,
        loginMethod: "discord",
        lastSignedIn: new Date(),
      });
    }
  }

  // Buscar usuário final
  user = await db.getUserByDiscordId(discordId);
  if (!user) {
    throw new Error("Falha ao criar/atualizar usuário Discord");
  }

  return user;
}

/**
 * Extrair token da requisição
 */
export function extractTokenFromRequest(req: any): string | null {
  // Verificar cookie
  const cookies = parseCookies(req.headers.cookie);
  const sessionCookie = cookies.get(COOKIE_NAME);
  if (sessionCookie) {
    return sessionCookie;
  }

  // Verificar header Authorization
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    return authHeader.substring(7);
  }

  return null;
}

/**
 * Parse cookies
 */
function parseCookies(cookieHeader: string | undefined): Map<string, string> {
  if (!cookieHeader) {
    return new Map();
  }

  const cookies = new Map<string, string>();
  cookieHeader.split(";").forEach((cookie) => {
    const [name, value] = cookie.trim().split("=");
    if (name && value) {
      cookies.set(name, decodeURIComponent(value));
    }
  });

  return cookies;
}

export { COOKIE_NAME, ONE_YEAR_MS };

/**
 * Gerar token de recuperacao de senha
 */
export function generatePasswordResetToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

/**
 * Solicitar recuperacao de senha
 */
export async function requestPasswordReset(email: string): Promise<{ token: string; expiresAt: Date }> {
  const user = await db.getUserByEmail(email);
  if (!user) {
    // Nao revelar se o email existe ou nao (seguranca)
    throw new Error("Se o email existir, voce recebera um link de recuperacao");
  }

  const token = generatePasswordResetToken();
  const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hora

  await db.upsertUser({
    email,
    passwordResetToken: token,
    passwordResetTokenExpires: expiresAt,
  });

  return { token, expiresAt };
}

/**
 * Verificar se token de recuperacao eh valido
 */
export async function verifyPasswordResetToken(email: string, token: string): Promise<boolean> {
  const user = await db.getUserByEmail(email);
  if (!user) return false;

  if (user.passwordResetToken !== token) return false;
  if (!user.passwordResetTokenExpires) return false;

  // Verificar se token expirou
  if (new Date() > user.passwordResetTokenExpires) return false;

  return true;
}

/**
 * Redefinir senha usando token
 */
export async function resetPasswordWithToken(
  email: string,
  token: string,
  newPassword: string
): Promise<User> {
  // Verificar token
  const isValid = await verifyPasswordResetToken(email, token);
  if (!isValid) {
    throw new Error("Token de recuperacao invalido ou expirado");
  }

  // Validar senha
  if (newPassword.length < 6) {
    throw new Error("Senha deve ter pelo menos 6 caracteres");
  }

  // Atualizar senha e limpar token
  const passwordHash = hashPassword(newPassword);
  await db.upsertUser({
    email,
    passwordHash,
    passwordResetToken: null,
    passwordResetTokenExpires: null,
  });

  const user = await db.getUserByEmail(email);
  if (!user) {
    throw new Error("Falha ao redefinir senha");
  }

  return user;
}
