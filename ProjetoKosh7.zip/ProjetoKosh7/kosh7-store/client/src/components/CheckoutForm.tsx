import { useState } from "react";
import { Button } from "@/components/ui/button";
import { AlertCircle, Loader2, CreditCard, QrCode } from "lucide-react";

interface CheckoutFormProps {
  cartItems: Array<{ productId: number; quantity: number; price: string }>;
  totalAmount: string;
  onSuccess?: () => void;
}

export default function CheckoutForm({ cartItems, totalAmount, onSuccess }: CheckoutFormProps) {
  const [paymentMethod, setPaymentMethod] = useState<"card" | "pix">("card");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleCheckout = async () => {
    setError("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          items: cartItems,
          totalAmount,
          paymentMethod,
        }),
        credentials: "include",
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Falha ao processar pagamento");
      }

      const data = await response.json();

      if (paymentMethod === "card" && data.checkoutUrl) {
        // Redirecionar para Stripe Checkout
        window.location.href = data.checkoutUrl;
      } else if (paymentMethod === "pix" && data.pixData) {
        // Mostrar dados do PIX
        console.log("PIX Data:", data.pixData);
        // Aqui você poderia mostrar um modal com o QR code do PIX
      }

      onSuccess?.();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro ao processar pagamento");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto p-6 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold text-center mb-6 text-black">Checkout</h2>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-red-700">{error}</p>
        </div>
      )}

      {/* Resumo do pedido */}
      <div className="mb-6 p-4 bg-gray-50 rounded-lg">
        <h3 className="font-semibold text-black mb-3">Resumo do Pedido</h3>
        <div className="space-y-2">
          {cartItems.map((item) => (
            <div key={item.productId} className="flex justify-between text-sm text-gray-700">
              <span>Produto {item.productId} x {item.quantity}</span>
              <span>R$ {(parseFloat(item.price) * item.quantity).toFixed(2)}</span>
            </div>
          ))}
        </div>
        <div className="border-t border-gray-200 mt-3 pt-3 flex justify-between font-semibold text-black">
          <span>Total:</span>
          <span>R$ {parseFloat(totalAmount).toFixed(2)}</span>
        </div>
      </div>

      {/* Seleção de método de pagamento */}
      <div className="mb-6 space-y-3">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Método de Pagamento
        </label>

        <button
          onClick={() => setPaymentMethod("card")}
          className={`w-full p-4 rounded-lg border-2 transition flex items-center gap-3 ${
            paymentMethod === "card"
              ? "border-black bg-black/5"
              : "border-gray-200 hover:border-gray-300"
          }`}
        >
          <CreditCard className="w-5 h-5" />
          <div className="text-left">
            <div className="font-medium text-black">Cartão de Crédito</div>
            <div className="text-xs text-gray-600">Visa, Mastercard, etc</div>
          </div>
        </button>

        <button
          onClick={() => setPaymentMethod("pix")}
          className={`w-full p-4 rounded-lg border-2 transition flex items-center gap-3 ${
            paymentMethod === "pix"
              ? "border-black bg-black/5"
              : "border-gray-200 hover:border-gray-300"
          }`}
        >
          <QrCode className="w-5 h-5" />
          <div className="text-left">
            <div className="font-medium text-black">PIX</div>
            <div className="text-xs text-gray-600">Transferência instantânea</div>
          </div>
        </button>
      </div>

      {/* Botão de pagamento */}
      <Button
        onClick={handleCheckout}
        disabled={isLoading || cartItems.length === 0}
        className="w-full bg-black hover:bg-gray-800 text-white"
      >
        {isLoading ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Processando...
          </>
        ) : (
          `Pagar R$ ${parseFloat(totalAmount).toFixed(2)}`
        )}
      </Button>

      <p className="text-center text-xs text-gray-500 mt-4">
        Seus dados estão seguros. Pagamento processado por Stripe.
      </p>
    </div>
  );
}
