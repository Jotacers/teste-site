import { describe, it, expect, beforeEach, vi } from "vitest";
import * as auth from "./auth";
import * as db from "./db";

// Mock do módulo db
vi.mock("./db", () => ({
  getUserByEmail: vi.fn(),
  upsertUser: vi.fn(),
}));

describe("Password Reset Flow", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("generatePasswordResetToken", () => {
    it("should generate a valid token", () => {
      const token = auth.generatePasswordResetToken();
      expect(token).toBeTruthy();
      expect(token.length).toBeGreaterThan(0);
      expect(typeof token).toBe("string");
    });

    it("should generate unique tokens", () => {
      const token1 = auth.generatePasswordResetToken();
      const token2 = auth.generatePasswordResetToken();
      expect(token1).not.toBe(token2);
    });
  });

  describe("requestPasswordReset", () => {
    it("should request password reset for existing user", async () => {
      const mockUser = {
        id: 1,
        email: "user@example.com",
        name: "Test User",
        passwordHash: "hash",
        discordId: null,
        discordUsername: null,
        discordAvatar: null,
        loginMethod: "email",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
        passwordResetToken: null,
        passwordResetTokenExpires: null,
      };

      vi.mocked(db.getUserByEmail).mockResolvedValue(mockUser);
      vi.mocked(db.upsertUser).mockResolvedValue(undefined);

      const result = await auth.requestPasswordReset("user@example.com");

      expect(result.token).toBeTruthy();
      expect(result.expiresAt).toBeInstanceOf(Date);
      expect(result.expiresAt.getTime()).toBeGreaterThan(Date.now());
      expect(vi.mocked(db.upsertUser)).toHaveBeenCalled();
    });

    it("should throw error for non-existing user", async () => {
      vi.mocked(db.getUserByEmail).mockResolvedValue(null);

      await expect(auth.requestPasswordReset("nonexistent@example.com")).rejects.toThrow();
    });

    it("should set token expiration to 1 hour", async () => {
      const mockUser = {
        id: 1,
        email: "user@example.com",
        name: "Test User",
        passwordHash: "hash",
        discordId: null,
        discordUsername: null,
        discordAvatar: null,
        loginMethod: "email",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
        passwordResetToken: null,
        passwordResetTokenExpires: null,
      };

      vi.mocked(db.getUserByEmail).mockResolvedValue(mockUser);
      vi.mocked(db.upsertUser).mockResolvedValue(undefined);

      const before = Date.now();
      const result = await auth.requestPasswordReset("user@example.com");
      const after = Date.now();

      const expectedMin = before + 59 * 60 * 1000; // 59 minutos
      const expectedMax = after + 61 * 60 * 1000; // 61 minutos

      expect(result.expiresAt.getTime()).toBeGreaterThanOrEqual(expectedMin);
      expect(result.expiresAt.getTime()).toBeLessThanOrEqual(expectedMax);
    });
  });

  describe("verifyPasswordResetToken", () => {
    it("should verify valid token", async () => {
      const token = auth.generatePasswordResetToken();
      const expiresAt = new Date(Date.now() + 60 * 60 * 1000);

      const mockUser = {
        id: 1,
        email: "user@example.com",
        name: "Test User",
        passwordHash: "hash",
        discordId: null,
        discordUsername: null,
        discordAvatar: null,
        loginMethod: "email",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
        passwordResetToken: token,
        passwordResetTokenExpires: expiresAt,
      };

      vi.mocked(db.getUserByEmail).mockResolvedValue(mockUser);

      const isValid = await auth.verifyPasswordResetToken("user@example.com", token);
      expect(isValid).toBe(true);
    });

    it("should reject expired token", async () => {
      const token = auth.generatePasswordResetToken();
      const expiresAt = new Date(Date.now() - 1000); // Expirado há 1 segundo

      const mockUser = {
        id: 1,
        email: "user@example.com",
        name: "Test User",
        passwordHash: "hash",
        discordId: null,
        discordUsername: null,
        discordAvatar: null,
        loginMethod: "email",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
        passwordResetToken: token,
        passwordResetTokenExpires: expiresAt,
      };

      vi.mocked(db.getUserByEmail).mockResolvedValue(mockUser);

      const isValid = await auth.verifyPasswordResetToken("user@example.com", token);
      expect(isValid).toBe(false);
    });

    it("should reject wrong token", async () => {
      const expiresAt = new Date(Date.now() + 60 * 60 * 1000);

      const mockUser = {
        id: 1,
        email: "user@example.com",
        name: "Test User",
        passwordHash: "hash",
        discordId: null,
        discordUsername: null,
        discordAvatar: null,
        loginMethod: "email",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
        passwordResetToken: "correct-token",
        passwordResetTokenExpires: expiresAt,
      };

      vi.mocked(db.getUserByEmail).mockResolvedValue(mockUser);

      const isValid = await auth.verifyPasswordResetToken("user@example.com", "wrong-token");
      expect(isValid).toBe(false);
    });

    it("should reject if user not found", async () => {
      vi.mocked(db.getUserByEmail).mockResolvedValue(null);

      const isValid = await auth.verifyPasswordResetToken("nonexistent@example.com", "token");
      expect(isValid).toBe(false);
    });
  });

  describe("resetPasswordWithToken", () => {
    it("should reset password with valid token", async () => {
      const token = auth.generatePasswordResetToken();
      const expiresAt = new Date(Date.now() + 60 * 60 * 1000);

      const mockUser = {
        id: 1,
        email: "user@example.com",
        name: "Test User",
        passwordHash: "hash",
        discordId: null,
        discordUsername: null,
        discordAvatar: null,
        loginMethod: "email",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
        passwordResetToken: token,
        passwordResetTokenExpires: expiresAt,
      };

      const updatedUser = {
        ...mockUser,
        passwordHash: auth.hashPassword("newpassword123"),
        passwordResetToken: null,
        passwordResetTokenExpires: null,
      };

      vi.mocked(db.getUserByEmail)
        .mockResolvedValueOnce(mockUser)
        .mockResolvedValueOnce(updatedUser);
      vi.mocked(db.upsertUser).mockResolvedValue(undefined);

      const result = await auth.resetPasswordWithToken(
        "user@example.com",
        token,
        "newpassword123"
      );

      expect(result.email).toBe("user@example.com");
      expect(result.passwordResetToken).toBeNull();
      expect(result.passwordResetTokenExpires).toBeNull();
    });

    it("should reject reset with expired token", async () => {
      const token = auth.generatePasswordResetToken();
      const expiresAt = new Date(Date.now() - 1000); // Expirado

      const mockUser = {
        id: 1,
        email: "user@example.com",
        name: "Test User",
        passwordHash: "hash",
        discordId: null,
        discordUsername: null,
        discordAvatar: null,
        loginMethod: "email",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
        passwordResetToken: token,
        passwordResetTokenExpires: expiresAt,
      };

      vi.mocked(db.getUserByEmail).mockResolvedValue(mockUser);

      await expect(
        auth.resetPasswordWithToken("user@example.com", token, "newpassword123")
      ).rejects.toThrow("invalido ou expirado");
    });

    it("should reject password shorter than 6 characters", async () => {
      const token = auth.generatePasswordResetToken();
      const expiresAt = new Date(Date.now() + 60 * 60 * 1000);

      const mockUser = {
        id: 1,
        email: "user@example.com",
        name: "Test User",
        passwordHash: "hash",
        discordId: null,
        discordUsername: null,
        discordAvatar: null,
        loginMethod: "email",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
        passwordResetToken: token,
        passwordResetTokenExpires: expiresAt,
      };

      vi.mocked(db.getUserByEmail).mockResolvedValue(mockUser);

      await expect(
        auth.resetPasswordWithToken("user@example.com", token, "123")
      ).rejects.toThrow("pelo menos 6 caracteres");
    });
  });
});
