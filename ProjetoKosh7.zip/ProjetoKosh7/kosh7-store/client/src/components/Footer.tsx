export default function Footer() {
  return (
    <footer className="border-t border-white/10 py-12">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {/* Sobre */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <img
                src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663290592505/pGtmFzPERlbAWazr.png"
                alt="Yin-yang"
                width="24"
                height="24"
              />
              <span className="text-white font-bold">Kosh7 Store</span>
            </div>
            <p className="text-white/60 text-sm">
              A loja amadora que busca vencer e virar a líder em venda de software e serviços para jogos.
            </p>
          </div>

          {/* Links */}
          <div className="flex flex-col gap-4">
            <h4 className="text-white font-bold">Navegação</h4>
            <a href="#" className="text-white/60 hover:text-white transition-colors text-sm">
              Página Inicial
            </a>
            <a href="#" className="text-white/60 hover:text-white transition-colors text-sm">
              Nossa Loja
            </a>
            <a href="#" className="text-white/60 hover:text-white transition-colors text-sm">
              Suporte
            </a>
          </div>

          {/* Legal */}
          <div className="flex flex-col gap-4">
            <h4 className="text-white font-bold">Legal</h4>
            <a href="#" className="text-white/60 hover:text-white transition-colors text-sm">
              Termos de Serviço
            </a>
            <a href="#" className="text-white/60 hover:text-white transition-colors text-sm">
              Política de Privacidade
            </a>
            <a href="#" className="text-white/60 hover:text-white transition-colors text-sm">
              Blog
            </a>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-white/10 pt-8">
          <p className="text-white/50 text-sm text-center">
            © 2026 Kosh7 Store. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
