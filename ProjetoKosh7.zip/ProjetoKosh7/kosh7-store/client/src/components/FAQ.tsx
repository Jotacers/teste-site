import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: 'Como posso fazer um pedido?',
      answer: 'Para fazer um pedido, basta selecionar os produtos desejados e seguir para o checkout. Aceitamos diversas formas de pagamento, incluindo cartão de crédito, débito e carteiras digitais.',
    },
    {
      question: 'Qual o prazo de entrega?',
      answer: 'A entrega é feita de forma imediata após a confirmação do pagamento. Você receberá o acesso ao seu produto em poucos segundos.',
    },
    {
      question: 'Como funciona o suporte?',
      answer: 'Nosso suporte está disponível 24/7 através do Discord. Clique no botão "Suporte" no topo da página para entrar em contato com nossa equipe.',
    },
  ];

  return (
    <section className="py-20">
      <div className="container max-w-3xl">
        <div className="mb-12 text-center">
          <h2 className="text-white mb-2 text-4xl font-bold">Perguntas frequentes</h2>
          <p className="text-white/60">Veja as perguntas mais comuns e suas respostas</p>
        </div>

        <div className="flex flex-col gap-4">
          {faqs.map((faq, index) => (
            <button
              key={index}
              onClick={() => setOpenIndex(openIndex === index ? null : index)}
              className="w-full text-left"
            >
              <div className={`border-2 rounded-lg p-6 transition-all duration-300 ${
                openIndex === index
                  ? 'border-white/40 bg-white/10'
                  : 'border-white/20 bg-white/5 hover:bg-white/10'
              }`}>
                <div className="flex items-center justify-between">
                  <h3 className="text-white font-semibold text-lg">{faq.question}</h3>
                  <ChevronDown
                    size={24}
                    className={`text-white/60 transition-transform duration-300 flex-shrink-0 ${
                      openIndex === index ? 'rotate-180' : ''
                    }`}
                  />
                </div>
                {openIndex === index && (
                  <div className="mt-4 pt-4 border-t border-white/20">
                    <p className="text-white/70 leading-relaxed">{faq.answer}</p>
                  </div>
                )}
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
