import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import LoginForm from "./LoginForm";
import RegisterForm from "./RegisterForm";
import AuthModal from "./AuthModal";
import DiscordAuthButton from "./DiscordAuthButton";

// Mock fetch
global.fetch = vi.fn();

// Mock window.location
delete (window as any).location;
window.location = { href: "", origin: "http://localhost:3000" } as any;

describe("Authentication Components", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    (global.fetch as any).mockClear();
  });

  describe("LoginForm", () => {
    it("should render login form with email and password fields", () => {
      render(<LoginForm />);
      
      expect(screen.getByLabelText(/email/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/senha/i)).toBeInTheDocument();
      expect(screen.getByRole("button", { name: /entrar/i })).toBeInTheDocument();
    });

    it("should show error message on failed login", async () => {
      (global.fetch as any).mockResolvedValueOnce({
        ok: false,
        json: async () => ({ error: "Email ou senha inválidos" }),
      });

      render(<LoginForm />);
      
      const emailInput = screen.getByLabelText(/email/i) as HTMLInputElement;
      const passwordInput = screen.getByLabelText(/senha/i) as HTMLInputElement;
      const submitButton = screen.getByRole("button", { name: /entrar/i });

      fireEvent.change(emailInput, { target: { value: "test@example.com" } });
      fireEvent.change(passwordInput, { target: { value: "password123" } });
      fireEvent.click(submitButton);

      await waitFor(() => {
        expect(screen.getByText(/email ou senha inválidos/i)).toBeInTheDocument();
      });
    });

    it("should have Discord login button", () => {
      render(<LoginForm />);
      expect(screen.getByRole("button", { name: /discord/i })).toBeInTheDocument();
    });

    it("should have link to switch to register", () => {
      const mockSwitch = vi.fn();
      render(<LoginForm onSwitchToRegister={mockSwitch} />);
      
      const registerLink = screen.getByRole("button", { name: /registre-se/i });
      fireEvent.click(registerLink);
      
      expect(mockSwitch).toHaveBeenCalled();
    });
  });

  describe("RegisterForm", () => {
    it("should render register form with all required fields", () => {
      render(<RegisterForm />);
      
      expect(screen.getByLabelText(/nome completo/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/email/i)).toBeInTheDocument();
      expect(screen.getAllByLabelText(/senha/i)).toHaveLength(2);
      expect(screen.getByRole("button", { name: /criar conta/i })).toBeInTheDocument();
    });

    it("should show error if passwords don't match", async () => {
      render(<RegisterForm />);
      
      const nameInput = screen.getByLabelText(/nome completo/i) as HTMLInputElement;
      const emailInput = screen.getByLabelText(/email/i) as HTMLInputElement;
      const passwordInputs = screen.getAllByLabelText(/senha/i);
      const submitButton = screen.getByRole("button", { name: /criar conta/i });

      fireEvent.change(nameInput, { target: { value: "Test User" } });
      fireEvent.change(emailInput, { target: { value: "test@example.com" } });
      fireEvent.change(passwordInputs[0], { target: { value: "password123" } });
      fireEvent.change(passwordInputs[1], { target: { value: "password456" } });
      fireEvent.click(submitButton);

      await waitFor(() => {
        expect(screen.getByText(/senhas não correspondem/i)).toBeInTheDocument();
      });
    });

    it("should show error if password is too short", async () => {
      render(<RegisterForm />);
      
      const nameInput = screen.getByLabelText(/nome completo/i) as HTMLInputElement;
      const emailInput = screen.getByLabelText(/email/i) as HTMLInputElement;
      const passwordInputs = screen.getAllByLabelText(/senha/i);
      const submitButton = screen.getByRole("button", { name: /criar conta/i });

      fireEvent.change(nameInput, { target: { value: "Test User" } });
      fireEvent.change(emailInput, { target: { value: "test@example.com" } });
      fireEvent.change(passwordInputs[0], { target: { value: "123" } });
      fireEvent.change(passwordInputs[1], { target: { value: "123" } });
      fireEvent.click(submitButton);

      await waitFor(() => {
        expect(screen.getByText(/mínimo 6 caracteres/i)).toBeInTheDocument();
      });
    });

    it("should have Discord login button", () => {
      render(<RegisterForm />);
      expect(screen.getByRole("button", { name: /discord/i })).toBeInTheDocument();
    });

    it("should have link to switch to login", () => {
      const mockSwitch = vi.fn();
      render(<RegisterForm onSwitchToLogin={mockSwitch} />);
      
      const loginLink = screen.getByRole("button", { name: /faça login/i });
      fireEvent.click(loginLink);
      
      expect(mockSwitch).toHaveBeenCalled();
    });
  });

  describe("AuthModal", () => {
    it("should not render when isOpen is false", () => {
      const { container } = render(<AuthModal isOpen={false} onClose={() => {}} />);
      expect(container.firstChild).toBeNull();
    });

    it("should render with login tab by default", () => {
      render(<AuthModal isOpen={true} onClose={() => {}} />);
      
      expect(screen.getByLabelText(/email/i)).toBeInTheDocument();
      expect(screen.getByRole("button", { name: /entrar/i })).toBeInTheDocument();
    });

    it("should switch to register tab when clicked", () => {
      render(<AuthModal isOpen={true} onClose={() => {}} initialTab="login" />);
      
      const registerTab = screen.getByRole("button", { name: /registrar/i });
      fireEvent.click(registerTab);
      
      expect(screen.getByLabelText(/nome completo/i)).toBeInTheDocument();
    });

    it("should have close button", () => {
      const mockClose = vi.fn();
      render(<AuthModal isOpen={true} onClose={mockClose} />);
      
      const closeButton = screen.getByRole("button", { name: "" });
      fireEvent.click(closeButton);
      
      expect(mockClose).toHaveBeenCalled();
    });
  });

  describe("DiscordAuthButton", () => {
    it("should render Discord button", () => {
      render(<DiscordAuthButton />);
      expect(screen.getByRole("button", { name: /discord/i })).toBeInTheDocument();
    });

    it("should show error if Discord client ID is not configured", () => {
      // Clear VITE_DISCORD_CLIENT_ID
      delete (import.meta.env as any).VITE_DISCORD_CLIENT_ID;
      
      render(<DiscordAuthButton />);
      const button = screen.getByRole("button", { name: /discord/i });
      fireEvent.click(button);
      
      expect(screen.getByText(/discord não está configurado/i)).toBeInTheDocument();
    });

    it("should be disabled when isLoading is true", () => {
      render(<DiscordAuthButton isLoading={true} />);
      const button = screen.getByRole("button", { name: /discord/i });
      expect(button).toBeDisabled();
    });
  });
});
