export default function YinYangLogo() {
  return (
    <div className="flex justify-center items-center py-12">
      <img
        src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663290592505/pGtmFzPERlbAWazr.png"
        alt="Yin-yang"
        width="220"
        height="220"
        className="yinyang-container"
      />
    </div>
  );
}
