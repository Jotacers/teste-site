import { ShoppingCart, Menu, X, MessageCircle, LogOut } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import AuthModal from './AuthModal';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const { user, logout, isAuthenticated } = useAuth();

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include",
      });
      logout();
      window.location.href = "/";
    } catch (error) {
      console.error("Erro ao fazer logout:", error);
    }
  };

  return (
    <>
      {/* Barra de anúncio */}
      <div className="bg-white text-black text-center py-3 text-sm font-semibold">
        ENTRE EM NOSSO DISCORD E TENHA ACESSO A ATENDIMENTO EM TEMPO REAL
      </div>

      {/* Header principal */}
      <header className="bg-background border-b border-white/10 sticky top-0 z-40">
        <div className="container flex items-center justify-between py-4">
          {/* Logo e Botão Suporte */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <img
                src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663290592505/pGtmFzPERlbAWazr.png"
                alt="Yin-yang"
                width="32"
                height="32"
                className="yinyang-container-small"
              />
              <div className="flex flex-col">
                <span className="text-white font-bold text-lg">Kosh7</span>
                <span className="text-white/60 text-xs">STORE</span>
              </div>
            </div>
            
            {/* Botão Suporte */}
            <a
              href="https://discord.gg/waD9MFdD"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden md:flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/20 hover:border-white/40 rounded-full px-4 py-2 transition-colors"
            >
              <MessageCircle size={16} className="text-white" />
              <span className="text-white text-sm font-semibold">Suporte</span>
            </a>
          </div>

          {/* Navegação Desktop */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="#" className="text-white/80 hover:text-white transition-colors">
              Loja
            </a>
            <a href="#" className="text-white/80 hover:text-white transition-colors">
              Categorias
            </a>
          </nav>

          {/* Ações direita */}
          <div className="flex items-center gap-4">
            <input
              type="text"
              placeholder="Buscar produto"
              className="hidden md:block bg-white/10 border border-white/20 rounded px-4 py-2 text-white placeholder-white/50 focus:outline-none focus:border-white/40 transition-colors"
            />
            
            {isAuthenticated && user ? (
              <>
                <span className="text-white/80 text-sm hidden sm:inline">
                  {user.name || user.email}
                </span>
                <button
                  onClick={handleLogout}
                  className="text-white/80 hover:text-white transition-colors flex items-center gap-2"
                >
                  <LogOut size={18} />
                  <span className="hidden sm:inline">Sair</span>
                </button>
              </>
            ) : (
              <button
                onClick={() => setIsAuthModalOpen(true)}
                className="text-white/80 hover:text-white transition-colors"
              >
                Entrar
              </button>
            )}
            
            <button className="bg-white text-black px-4 py-2 rounded font-semibold hover:bg-white/90 transition-colors flex items-center gap-2">
              <ShoppingCart size={18} />
              <span className="hidden sm:inline">Carrinho</span>
            </button>

            {/* Menu mobile */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-white"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Menu mobile expandido */}
        {isMenuOpen && (
          <nav className="md:hidden bg-background/95 border-t border-white/10 py-4 px-4 flex flex-col gap-4">
            <a href="#" className="text-white/80 hover:text-white transition-colors">
              Loja
            </a>
            <a href="#" className="text-white/80 hover:text-white transition-colors">
              Categorias
            </a>
            <a
              href="https://discord.gg/waD9MFdD"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-white/80 hover:text-white transition-colors"
            >
              <MessageCircle size={16} />
              Suporte
            </a>
            <input
              type="text"
              placeholder="Buscar produto"
              className="bg-white/10 border border-white/20 rounded px-4 py-2 text-white placeholder-white/50 focus:outline-none focus:border-white/40 transition-colors"
            />
          </nav>
        )}
      </header>

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        initialTab="login"
      />
    </>
  );
}
