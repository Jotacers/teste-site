import { useState } from "react";
import { Button } from "@/components/ui/button";
import { AlertCircle } from "lucide-react";

interface DiscordAuthButtonProps {
  isLoading?: boolean;
  className?: string;
}

export default function DiscordAuthButton({ isLoading = false, className = "" }: DiscordAuthButtonProps) {
  const [error, setError] = useState("");

  const handleDiscordLogin = () => {
    setError("");
    
    const redirectUri = `${window.location.origin}/api/oauth/discord/callback`;
    const state = btoa(redirectUri);
    const clientId = import.meta.env.VITE_DISCORD_CLIENT_ID || "";
    
    if (!clientId) {
      setError("Discord não está configurado");
      return;
    }

    const discordUrl = `https://discord.com/oauth2/authorize?client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=identify%20email&state=${state}`;
    window.location.href = discordUrl;
  };

  return (
    <div>
      {error && (
        <div className="mb-3 p-2 bg-red-50 border border-red-200 rounded flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-red-700">{error}</p>
        </div>
      )}
      <Button
        type="button"
        onClick={handleDiscordLogin}
        disabled={isLoading}
        className={`w-full bg-[#5865F2] hover:bg-[#4752C4] text-white ${className}`}
      >
        Discord
      </Button>
    </div>
  );
}
