import { useEffect, useState } from "react";
import { Loader2, ShoppingBag, AlertCircle } from "lucide-react";

interface Order {
  id: number;
  totalAmount: string;
  status: "pending" | "completed" | "cancelled" | "refunded";
  items: Array<{ productId: number; quantity: number; price: string }>;
  createdAt: Date;
  paymentMethod?: string;
}

interface OrdersTabProps {
  userId: number;
}

export default function OrdersTab({ userId }: OrdersTabProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchOrders();
  }, [userId]);

  const fetchOrders = async () => {
    try {
      const response = await fetch(`/api/orders?userId=${userId}`, {
        credentials: "include",
      });

      if (!response.ok) {
        throw new Error("Falha ao carregar pedidos");
      }

      const data = await response.json();
      setOrders(data.orders || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro ao carregar pedidos");
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-500/20 text-green-400";
      case "pending":
        return "bg-yellow-500/20 text-yellow-400";
      case "cancelled":
        return "bg-red-500/20 text-red-400";
      case "refunded":
        return "bg-blue-500/20 text-blue-400";
      default:
        return "bg-gray-500/20 text-gray-400";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "completed":
        return "Concluído";
      case "pending":
        return "Pendente";
      case "cancelled":
        return "Cancelado";
      case "refunded":
        return "Reembolsado";
      default:
        return status;
    }
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("pt-BR");
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-white mx-auto mb-2" />
          <p className="text-gray-400">Carregando pedidos...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
        <p className="text-red-400">{error}</p>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="bg-gray-900 rounded-lg border border-gray-800 p-12 text-center">
        <ShoppingBag className="w-12 h-12 text-gray-600 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-white mb-2">Nenhum pedido encontrado</h3>
        <p className="text-gray-400">Você ainda não realizou nenhuma compra.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-white mb-6">Histórico de Pedidos</h2>

      {orders.map((order) => (
        <div key={order.id} className="bg-gray-900 rounded-lg border border-gray-800 p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-lg font-semibold text-white">Pedido #{order.id}</h3>
              <p className="text-gray-400 text-sm">{formatDate(order.createdAt)}</p>
            </div>
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.status)}`}>
              {getStatusLabel(order.status)}
            </span>
          </div>

          {/* Itens do Pedido */}
          <div className="mb-4 pb-4 border-b border-gray-800">
            <p className="text-gray-400 text-sm mb-2">
              {order.items.length} {order.items.length === 1 ? "produto" : "produtos"}
            </p>
            <div className="space-y-2">
              {order.items.map((item, idx) => (
                <div key={idx} className="flex justify-between text-sm text-gray-400">
                  <span>Produto {item.productId} x {item.quantity}</span>
                  <span>R$ {(parseFloat(item.price) * item.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Resumo */}
          <div className="flex justify-between items-center">
            <div>
              {order.paymentMethod && (
                <p className="text-sm text-gray-400">
                  Método: <span className="text-white capitalize">{order.paymentMethod}</span>
                </p>
              )}
            </div>
            <div className="text-right">
              <p className="text-gray-400 text-sm">Total</p>
              <p className="text-2xl font-bold text-white">R$ {parseFloat(order.totalAmount).toFixed(2)}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
