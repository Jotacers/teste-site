import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import type { Express, Request, Response } from "express";
import { z } from "zod";
import axios, { AxiosError } from "axios";
import * as auth from "../auth";
import { getSessionCookieOptions } from "./cookies";
import { sdk } from "./sdk";

const discordApi = axios.create({
  baseURL: "https://discord.com/api/v10",
});

const registerSchema = z.object({
  email: z.string().email("E-mail inválido"),
  password: z.string().min(8, "A senha deve ter pelo menos 8 caracteres"),
  name: z.string().min(2, "O nome deve ter pelo menos 2 caracteres").optional(),
});

const loginSchema = z.object({
  email: z.string().email("E-mail inválido"),
  password: z.string().min(1, "A senha é obrigatória"),
});

const getQueryParam = (req: Request, key: string): string | undefined => {
  const value = req.query[key];
  return typeof value === "string" ? value : undefined;
};

export function getDiscordLoginUrl(redirectUri: string): string {
  const clientId = process.env.DISCORD_CLIENT_ID || "";
  const state = Buffer.from(JSON.stringify({ redirectUri })).toString("base64");
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "identify email",
    state,
  });
  return `https://discord.com/oauth2/authorize?${params.toString()}`;
}

const discordService = {
  async exchangeCode(code: string, redirectUri: string) {
    const params = new URLSearchParams({
      client_id: process.env.DISCORD_CLIENT_ID || "",
      client_secret: process.env.DISCORD_CLIENT_SECRET || "",
      grant_type: "authorization_code",
      code,
      redirect_uri: redirectUri,
    });
    const { data } = await discordApi.post("/oauth2/token", params, {
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
    });
    return data;
  },
  async getUserInfo(accessToken: string) {
    const { data } = await discordApi.get("/users/@me", {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    return data;
  }
};

export function registerOAuthRoutes(app: Express) {
  app.get("/api/oauth/discord/callback", async (req: Request, res: Response) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");
    if (!code || !state) return res.status(400).json({ error: "Missing params" });

    try {
      const { redirectUri } = JSON.parse(Buffer.from(state, "base64").toString());
      const tokenData = await discordService.exchangeCode(code, redirectUri);
      const discordUser = await discordService.getUserInfo(tokenData.access_token);

      const user = await auth.loginWithDiscord(
        discordUser.id,
        discordUser.username,
        discordUser.avatar ? `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.png` : null,
        discordUser.email || `${discordUser.id}@discord.local`,
        discordUser.global_name || discordUser.username
      );

      const sessionToken = await sdk.createSessionToken(user.id!, user.email, { expiresInMs: ONE_YEAR_MS });
      res.cookie(COOKIE_NAME, sessionToken, { ...getSessionCookieOptions(req), maxAge: ONE_YEAR_MS });
      return res.redirect("/");
    } catch (error) {
      return res.status(500).json({ error: "Auth failed" });
    }
  });

  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const { email, password, name } = registerSchema.parse(req.body);
      const user = await auth.registerUser(email, password, name);
      const token = await sdk.createSessionToken(user.id!, user.email, { expiresInMs: ONE_YEAR_MS });
      res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(req), maxAge: ONE_YEAR_MS });
      return res.status(201).json({ user });
    } catch (error: any) {
      if (error instanceof z.ZodError) return res.status(400).json({ details: error.errors.map(e => e.message) });
      return res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      const user = await auth.loginWithEmail(email, password);
      const token = await sdk.createSessionToken(user.id!, user.email, { expiresInMs: ONE_YEAR_MS });
      res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(req), maxAge: ONE_YEAR_MS });
      return res.json({ user });
    } catch (error: any) {
      if (error instanceof z.ZodError) return res.status(400).json({ error: error.errors[0].message });
      return res.status(401).json({ error: "Invalid credentials" });
    }
  });

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    res.clearCookie(COOKIE_NAME, getSessionCookieOptions(req));
    return res.json({ success: true });
  });
}