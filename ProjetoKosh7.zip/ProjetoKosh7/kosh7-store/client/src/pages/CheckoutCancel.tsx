import { AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CheckoutCancel() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="w-full max-w-md p-6 bg-white rounded-lg shadow-lg text-center">
        <AlertCircle className="w-16 h-16 text-yellow-600 mx-auto mb-4" />
        <h1 className="text-2xl font-bold text-black mb-2">Pagamento Cancelado</h1>
        <p className="text-gray-600 mb-6">
          Você cancelou o processo de pagamento. Seu carrinho foi preservado.
        </p>

        <div className="space-y-3">
          <Button
            onClick={() => (window.location.href = "/cart")}
            className="w-full bg-black hover:bg-gray-800 text-white"
          >
            Voltar para Carrinho
          </Button>
          <Button
            onClick={() => (window.location.href = "/")}
            variant="outline"
            className="w-full"
          >
            Continuar Comprando
          </Button>
        </div>
      </div>
    </div>
  );
}
