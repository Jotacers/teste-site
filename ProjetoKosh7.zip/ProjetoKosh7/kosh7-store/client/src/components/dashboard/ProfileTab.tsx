import { User } from "../../../drizzle/schema";
import { Mail, Calendar, Shield } from "lucide-react";

interface ProfileTabProps {
  user: User;
}

export default function ProfileTab({ user }: ProfileTabProps) {
  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("pt-BR", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  return (
    <div className="space-y-6">
      <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
        <h2 className="text-2xl font-bold text-white mb-6">Informações Pessoais</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Nome */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Nome</label>
            <div className="bg-gray-800 rounded-lg px-4 py-3 text-white">
              {user.name || "Não informado"}
            </div>
          </div>

          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Email</label>
            <div className="flex items-center gap-3 bg-gray-800 rounded-lg px-4 py-3 text-white">
              <Mail className="w-4 h-4 text-gray-400" />
              {user.email}
            </div>
          </div>

          {/* Método de Login */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Método de Login</label>
            <div className="flex items-center gap-3 bg-gray-800 rounded-lg px-4 py-3 text-white capitalize">
              <Shield className="w-4 h-4 text-gray-400" />
              {user.loginMethod === "email" ? "Email e Senha" : "Discord"}
            </div>
          </div>

          {/* Conta Criada */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Conta Criada</label>
            <div className="flex items-center gap-3 bg-gray-800 rounded-lg px-4 py-3 text-white">
              <Calendar className="w-4 h-4 text-gray-400" />
              {formatDate(user.createdAt)}
            </div>
          </div>

          {/* Último Acesso */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Último Acesso</label>
            <div className="flex items-center gap-3 bg-gray-800 rounded-lg px-4 py-3 text-white">
              <Calendar className="w-4 h-4 text-gray-400" />
              {user.lastSignedIn ? formatDate(user.lastSignedIn) : "Primeira vez"}
            </div>
          </div>

          {/* Status da Conta */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Status</label>
            <div className="bg-gray-800 rounded-lg px-4 py-3">
              <span className="inline-block px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-sm font-medium">
                Ativa
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Discord Info */}
      {user.discordId && (
        <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
          <h3 className="text-lg font-bold text-white mb-4">Conta Discord Vinculada</h3>
          <div className="flex items-center gap-4">
            {user.discordAvatar && (
              <img
                src={user.discordAvatar}
                alt="Avatar Discord"
                className="w-16 h-16 rounded-full"
              />
            )}
            <div>
              <p className="text-white font-medium">{user.discordUsername}</p>
              <p className="text-gray-400 text-sm">ID: {user.discordId}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
