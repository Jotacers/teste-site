import { useState } from "react";
import { X } from "lucide-react";
import LoginForm from "./LoginForm";
import RegisterForm from "./RegisterForm";
import ForgotPasswordForm from "./ForgotPasswordForm";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: "login" | "register" | "forgot";
}

export default function AuthModal({ isOpen, onClose, initialTab = "login" }: AuthModalProps) {
  const [activeTab, setActiveTab] = useState<"login" | "register" | "forgot">(initialTab);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="relative w-full max-w-md">
        <button
          onClick={onClose}
          className="absolute -top-10 right-0 text-white hover:text-gray-300 transition"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="bg-white rounded-lg shadow-xl overflow-hidden">
          {activeTab !== "forgot" && (
            <div className="flex border-b border-gray-200">
              <button
                onClick={() => setActiveTab("login")}
                className={`flex-1 py-3 px-4 font-medium transition ${
                  activeTab === "login"
                    ? "bg-black text-white"
                    : "bg-gray-50 text-gray-700 hover:bg-gray-100"
                }`}
              >
                Entrar
              </button>
              <button
                onClick={() => setActiveTab("register")}
                className={`flex-1 py-3 px-4 font-medium transition ${
                  activeTab === "register"
                    ? "bg-black text-white"
                    : "bg-gray-50 text-gray-700 hover:bg-gray-100"
                }`}
              >
                Registrar
              </button>
            </div>
          )}

          <div className="p-6">
            {activeTab === "login" ? (
              <LoginForm
                onLoginSuccess={onClose}
                onSwitchToRegister={() => setActiveTab("register")}
                onForgotPassword={() => setActiveTab("forgot")}
              />
            ) : activeTab === "register" ? (
              <RegisterForm
                onRegisterSuccess={onClose}
                onSwitchToLogin={() => setActiveTab("login")}
              />
            ) : (
              <ForgotPasswordForm
                onBackToLogin={() => setActiveTab("login")}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
