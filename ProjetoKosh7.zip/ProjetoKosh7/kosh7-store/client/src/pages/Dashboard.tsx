import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { AlertCircle, Loader2, LogOut, User, ShoppingBag, Settings } from "lucide-react";
import ProfileTab from "@/components/dashboard/ProfileTab";
import OrdersTab from "@/components/dashboard/OrdersTab";
import SettingsTab from "@/components/dashboard/SettingsTab";
import { useLocation } from "wouter";

export default function Dashboard() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<"profile" | "orders" | "settings">("profile");

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-white mx-auto mb-4" />
          <p className="text-white">Carregando dashboard...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-full max-w-md p-6 bg-white rounded-lg shadow-lg text-center">
          <AlertCircle className="w-12 h-12 text-red-600 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-black mb-2">Acesso Negado</h1>
          <p className="text-gray-600 mb-6">Você precisa estar autenticado para acessar o dashboard.</p>
          <Button
            onClick={() => setLocation("/")}
            className="w-full bg-black hover:bg-gray-800 text-white"
          >
            Voltar para Home
          </Button>
        </div>
      </div>
    );
  }

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-black text-white border-b border-gray-800">
        <div className="max-w-6xl mx-auto px-4 py-6 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-gray-400 mt-1">Bem-vindo, {user.name || user.email}</p>
          </div>
          <Button
            onClick={handleLogout}
            className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white"
          >
            <LogOut className="w-4 h-4" />
            Sair
          </Button>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="bg-gray-900 border-b border-gray-800 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 flex">
          <button
            onClick={() => setActiveTab("profile")}
            className={`px-6 py-4 font-medium transition flex items-center gap-2 ${
              activeTab === "profile"
                ? "text-white border-b-2 border-white"
                : "text-gray-400 hover:text-white"
            }`}
          >
            <User className="w-4 h-4" />
            Perfil
          </button>
          <button
            onClick={() => setActiveTab("orders")}
            className={`px-6 py-4 font-medium transition flex items-center gap-2 ${
              activeTab === "orders"
                ? "text-white border-b-2 border-white"
                : "text-gray-400 hover:text-white"
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            Pedidos
          </button>
          <button
            onClick={() => setActiveTab("settings")}
            className={`px-6 py-4 font-medium transition flex items-center gap-2 ${
              activeTab === "settings"
                ? "text-white border-b-2 border-white"
                : "text-gray-400 hover:text-white"
            }`}
          >
            <Settings className="w-4 h-4" />
            Configurações
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        {activeTab === "profile" && <ProfileTab user={user} />}
        {activeTab === "orders" && <OrdersTab userId={user.id} />}
        {activeTab === "settings" && <SettingsTab user={user} />}
      </div>
    </div>
  );
}
