/**
 * SDK independente que não depende do Manus OAuth
 * Usado apenas para funções auxiliares que não envolvem autenticação
 */

import { AXIOS_TIMEOUT_MS } from "@shared/const";
import axios, { type AxiosInstance } from "axios";

const createHttpClient = (): AxiosInstance =>
  axios.create({
    timeout: AXIOS_TIMEOUT_MS,
  });

class SDKIndependent {
  private readonly client: AxiosInstance;

  constructor(client: AxiosInstance = createHttpClient()) {
    this.client = client;
  }

  /**
   * Fazer requisição HTTP genérica
   */
  async makeRequest(url: string, options: any = {}) {
    try {
      const response = await this.client({
        url,
        ...options,
      });
      return response.data;
    } catch (error) {
      console.error("[SDK] Request failed:", error);
      throw error;
    }
  }
}

export const sdkIndependent = new SDKIndependent();
