import { describe, it, expect, beforeEach, vi } from "vitest";
import * as auth from "./auth";
import * as db from "./db";

// Mock do módulo db
vi.mock("./db", () => ({
  getUserByEmail: vi.fn(),
  getUserByDiscordId: vi.fn(),
  upsertUser: vi.fn(),
  getUserById: vi.fn(),
}));

describe("Authentication Integration Tests", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Complete Login Flow", () => {
    it("should complete full email/password login flow", async () => {
      const password = "password123";
      const hash = auth.hashPassword(password);
      
      const mockUser = {
        id: 1,
        email: "user@example.com",
        name: "Test User",
        passwordHash: hash,
        discordId: null,
        discordUsername: null,
        discordAvatar: null,
        loginMethod: "email",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      vi.mocked(db.getUserByEmail).mockResolvedValue(mockUser);
      vi.mocked(db.upsertUser).mockResolvedValue(undefined);

      // 1. User logs in with email/password
      const user = await auth.loginWithEmail("user@example.com", password);
      expect(user).toBeTruthy();
      expect(user.email).toBe("user@example.com");

      // 2. Create session token
      const token = await auth.createSessionToken(user.id!, user.email);
      expect(token).toBeTruthy();

      // 3. Verify session token
      const session = await auth.verifySessionToken(token);
      expect(session).toBeTruthy();
      expect(session?.userId).toBe(user.id);
      expect(session?.email).toBe(user.email);
    });

    it("should complete full Discord OAuth flow", async () => {
      const mockUser = {
        id: 1,
        email: "user@discord.local",
        name: "Discord User",
        passwordHash: null,
        discordId: "123456",
        discordUsername: "discorduser",
        discordAvatar: "https://example.com/avatar.png",
        loginMethod: "discord",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      vi.mocked(db.getUserByDiscordId)
        .mockResolvedValueOnce(undefined)
        .mockResolvedValueOnce(mockUser);
      vi.mocked(db.getUserByEmail).mockResolvedValueOnce(undefined);
      vi.mocked(db.upsertUser).mockResolvedValue(undefined);

      // 1. User logs in with Discord
      const user = await auth.loginWithDiscord(
        "123456",
        "discorduser",
        "https://example.com/avatar.png",
        "user@discord.local",
        "Discord User"
      );
      expect(user).toBeTruthy();
      expect(user.discordId).toBe("123456");

      // 2. Create session token
      const token = await auth.createSessionToken(user.id!, user.email);
      expect(token).toBeTruthy();

      // 3. Verify session token
      const session = await auth.verifySessionToken(token);
      expect(session).toBeTruthy();
      expect(session?.userId).toBe(user.id);
    });
  });

  describe("Complete Registration Flow", () => {
    it("should complete full registration flow", async () => {
      const mockUser = {
        id: 1,
        email: "newuser@example.com",
        name: "New User",
        passwordHash: "hashed",
        discordId: null,
        discordUsername: null,
        discordAvatar: null,
        loginMethod: "email",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      vi.mocked(db.getUserByEmail)
        .mockResolvedValueOnce(undefined) // Check if user exists
        .mockResolvedValueOnce(mockUser); // Get created user
      vi.mocked(db.upsertUser).mockResolvedValue(undefined);

      // 1. Register new user
      const user = await auth.registerUser("newuser@example.com", "password123", "New User");
      expect(user).toBeTruthy();
      expect(user.email).toBe("newuser@example.com");

      // 2. Create session token
      const token = await auth.createSessionToken(user.id!, user.email);
      expect(token).toBeTruthy();

      // 3. Verify session token
      const session = await auth.verifySessionToken(token);
      expect(session).toBeTruthy();
      expect(session?.userId).toBe(user.id);
    });
  });

  describe("Session Management", () => {
    it("should handle token expiration", async () => {
      const userId = 1;
      const email = "test@example.com";
      
      // Create token with very short expiration
      const token = await auth.createSessionToken(userId, email, {
        expiresInMs: 1, // 1ms expiration
      });

      // Wait for token to expire
      await new Promise(resolve => setTimeout(resolve, 10));

      // Verify token is expired
      const session = await auth.verifySessionToken(token);
      expect(session).toBeNull();
    });

    it("should reject malformed tokens", async () => {
      const session = await auth.verifySessionToken("not.a.valid.token");
      expect(session).toBeNull();
    });

    it("should reject empty tokens", async () => {
      const session = await auth.verifySessionToken("");
      expect(session).toBeNull();
    });
  });

  describe("Security", () => {
    it("should not accept wrong password", async () => {
      const correctPassword = "correctpassword";
      const hash = auth.hashPassword(correctPassword);
      
      const isValid = auth.verifyPassword("wrongpassword", hash);
      expect(isValid).toBe(false);
    });

    it("should produce unique hashes for same password", () => {
      const password = "test123";
      const hash1 = auth.hashPassword(password);
      const hash2 = auth.hashPassword(password);
      
      expect(hash1).not.toBe(hash2);
      expect(auth.verifyPassword(password, hash1)).toBe(true);
      expect(auth.verifyPassword(password, hash2)).toBe(true);
    });

    it("should not expose password in user object", async () => {
      const password = "password123";
      const hash = auth.hashPassword(password);
      
      const mockUser = {
        id: 1,
        email: "user@example.com",
        name: "User",
        passwordHash: hash,
        discordId: null,
        discordUsername: null,
        discordAvatar: null,
        loginMethod: "email",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      vi.mocked(db.getUserByEmail).mockResolvedValue(mockUser);
      vi.mocked(db.upsertUser).mockResolvedValue(undefined);

      const user = await auth.loginWithEmail("user@example.com", password);
      
      // Password should not be returned
      expect(user).toBeTruthy();
      expect(user.passwordHash).toBeTruthy(); // Hash is stored but not the plain password
    });
  });
});
