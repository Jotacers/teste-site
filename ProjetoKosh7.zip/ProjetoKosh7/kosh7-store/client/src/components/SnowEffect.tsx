export default function SnowEffect() {
  return (
    <>
      <style>{`
        @keyframes snowfall {
          0% {
            transform: translateY(-10vh) translateX(0);
            opacity: 1;
          }
          90% {
            opacity: 1;
          }
          100% {
            transform: translateY(100vh) translateX(100px);
            opacity: 0;
          }
        }

        @keyframes sway {
          0%, 100% {
            transform: translateX(0);
          }
          50% {
            transform: translateX(50px);
          }
        }

        .snowflake {
          position: fixed;
          top: -10vh;
          color: white;
          font-size: 1.5em;
          text-shadow: 0 0 5px rgba(255, 255, 255, 0.8);
          pointer-events: none;
          z-index: -1;
          animation: snowfall linear infinite;
        }

        .snowflake:nth-child(1) {
          left: 10%;
          animation-duration: 10s;
          animation-delay: 0s;
          opacity: 0.8;
        }

        .snowflake:nth-child(2) {
          left: 20%;
          animation-duration: 12s;
          animation-delay: 1s;
          opacity: 0.6;
        }

        .snowflake:nth-child(3) {
          left: 30%;
          animation-duration: 14s;
          animation-delay: 2s;
          opacity: 0.7;
        }

        .snowflake:nth-child(4) {
          left: 40%;
          animation-duration: 11s;
          animation-delay: 0.5s;
          opacity: 0.8;
        }

        .snowflake:nth-child(5) {
          left: 50%;
          animation-duration: 13s;
          animation-delay: 1.5s;
          opacity: 0.6;
        }

        .snowflake:nth-child(6) {
          left: 60%;
          animation-duration: 15s;
          animation-delay: 2.5s;
          opacity: 0.7;
        }

        .snowflake:nth-child(7) {
          left: 70%;
          animation-duration: 10s;
          animation-delay: 0.2s;
          opacity: 0.8;
        }

        .snowflake:nth-child(8) {
          left: 80%;
          animation-duration: 12s;
          animation-delay: 1.2s;
          opacity: 0.6;
        }

        .snowflake:nth-child(9) {
          left: 90%;
          animation-duration: 14s;
          animation-delay: 2.2s;
          opacity: 0.7;
        }

        .snowflake:nth-child(10) {
          left: 5%;
          animation-duration: 11s;
          animation-delay: 0.8s;
          opacity: 0.8;
        }

        .snowflake:nth-child(11) {
          left: 25%;
          animation-duration: 13s;
          animation-delay: 1.8s;
          opacity: 0.6;
        }

        .snowflake:nth-child(12) {
          left: 45%;
          animation-duration: 15s;
          animation-delay: 2.8s;
          opacity: 0.7;
        }

        .snowflake:nth-child(13) {
          left: 65%;
          animation-duration: 10s;
          animation-delay: 0.3s;
          opacity: 0.8;
        }

        .snowflake:nth-child(14) {
          left: 85%;
          animation-duration: 12s;
          animation-delay: 1.3s;
          opacity: 0.6;
        }

        .snowflake:nth-child(15) {
          left: 15%;
          animation-duration: 14s;
          animation-delay: 2.3s;
          opacity: 0.7;
        }
      `}</style>

      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {[...Array(15)].map((_, i) => (
          <div key={i} className="snowflake">
            ❄
          </div>
        ))}
      </div>
    </>
  );
}
