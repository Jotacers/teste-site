# Kosh7 Store - TODO

## Autenticação e Segurança
- [x] Implementar autenticação OAuth com Discord
- [x] Implementar autenticação OAuth com Google
- [x] Implementar autenticação via Email com verificação
- [x] Criar página de login/registro unificada
- [ ] Implementar proteção anti-fraude
- [ ] Implementar proteção anti-hacking (rate limiting, CSRF, etc)

## Dashboard de Cliente
- [x] Criar página de dashboard do cliente
- [x] Implementar histórico de compras com tabela
- [x] Exibir valor da compra, horário e produto
- [x] Criar sistema de pedidos

## Carrinho de Compras
- [x] Implementar sistema de carrinho funcional
- [x] Adicionar/remover itens do carrinho
- [x] Persistência de carrinho (localStorage/DB)
- [ ] Cálculo de totais e impostos

## Produtos e Categorias
- [x] Criar tabela de produtos no banco
- [x] Criar tabela de categorias
- [x] Implementar grid de produtos na página inicial
- [x] Implementar filtros por categoria
- [ ] Criar categorias: Assinaturas, Streaming, Jogos, Call Of Duty
- [ ] Adicionar produtos de exemplo

## Interface e UX
- [x] Corrigir FAQ para expandir apenas um item por vez
- [ ] Criar página de categorias
- [x] Manter design minimalista zen (preto e branco)
- [x] Implementar responsividade completa

## Banco de Dados
- [x] Criar schema de produtos
- [x] Criar schema de categorias
- [x] Criar schema de pedidos/compras
- [x] Criar schema de carrinho
- [x] Executar migrações (pnpm db:push)

## Otimização e Segurança
- [x] Validar entrada de dados (Zod)
- [ ] Implementar rate limiting
- [ ] Implementar CSRF protection
- [ ] Otimizar queries do banco
- [x] Adicionar testes unitários (vitest)

## Funcionalidades em Tempo Real
- [ ] Registros de compras em tempo real
- [ ] Atualização de carrinho em tempo real
- [ ] Notificações de pedidos

## Publicação
- [ ] Testar todas as funcionalidades
- [ ] Verificar segurança
- [ ] Criar checkpoint final
- [ ] Publicar no Manus
