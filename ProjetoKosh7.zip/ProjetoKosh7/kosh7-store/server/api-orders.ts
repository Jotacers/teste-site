import { Router, Request, Response, NextFunction } from "express";
import { getDb } from "./db";
import { orders } from "../drizzle/schema";
import { eq, and } from "drizzle-orm";
import { extractTokenFromRequest, verifySessionToken } from "./auth";
import * as db from "./db";

const router = Router();

/**
 * Middleware de autenticação
 */
async function requireAuth(req: Request, res: Response, next: NextFunction) {
  try {
    const token = extractTokenFromRequest(req);
    if (!token) {
      return res.status(401).json({ error: "Não autenticado" });
    }

    const session = await verifySessionToken(token);
    if (!session) {
      return res.status(401).json({ error: "Token inválido" });
    }

    const user = await db.getUserById(session.userId);
    if (!user) {
      return res.status(401).json({ error: "Usuário não encontrado" });
    }

    (req as any).user = user;
    next();
  } catch (error) {
    return res.status(401).json({ error: "Não autenticado" });
  }
}

/**
 * GET /api/orders - Listar pedidos do usuário
 */
router.get("/orders", requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user?.id;

    if (!userId) {
      return res.status(401).json({ error: "Não autenticado" });
    }

    const userIdParam = req.query.userId ? parseInt(req.query.userId as string) : userId;

    // Verificar se o usuário está tentando acessar pedidos de outro usuário
    if (userIdParam !== userId) {
      return res.status(403).json({ error: "Acesso negado" });
    }

    const database = await getDb();
    if (!database) {
      return res.status(500).json({ error: "Banco de dados indisponível" });
    }

    // Buscar pedidos do usuário
    const userOrders = await database
      .select()
      .from(orders)
      .where(eq(orders.userId, userId));

    res.json({ orders: userOrders });
  } catch (error) {
    console.error("[API] Erro ao listar pedidos:", error);
    res.status(500).json({ error: "Erro ao listar pedidos" });
  }
});

/**
 * GET /api/orders/:id - Obter detalhes de um pedido
 */
router.get("/orders/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user?.id;
    const orderId = parseInt(req.params.id);

    if (!userId) {
      return res.status(401).json({ error: "Não autenticado" });
    }

    const database = await getDb();
    if (!database) {
      return res.status(500).json({ error: "Banco de dados indisponível" });
    }

    const order = await database
      .select()
      .from(orders)
      .where(and(eq(orders.id, orderId), eq(orders.userId, userId)));

    if (!order || order.length === 0) {
      return res.status(404).json({ error: "Pedido não encontrado" });
    }

    res.json({ order: order[0] });
  } catch (error) {
    console.error("[API] Erro ao obter pedido:", error);
    res.status(500).json({ error: "Erro ao obter pedido" });
  }
});

/**
 * POST /api/orders - Criar novo pedido
 */
router.post("/orders", requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user?.id;
    const { items, totalAmount, paymentMethod } = req.body;

    if (!userId) {
      return res.status(401).json({ error: "Não autenticado" });
    }

    if (!items || !totalAmount) {
      return res.status(400).json({ error: "Dados inválidos" });
    }

    const database = await getDb();
    if (!database) {
      return res.status(500).json({ error: "Banco de dados indisponível" });
    }

    // Criar pedido
    const result = await database.insert(orders).values({
      userId,
      totalAmount: totalAmount.toString(),
      items,
      status: "pending",
      paymentMethod: paymentMethod || "card",
    });

    res.status(201).json({
      orderId: (result as any).insertId,
      status: "pending",
    });
  } catch (error) {
    console.error("[API] Erro ao criar pedido:", error);
    res.status(500).json({ error: "Erro ao criar pedido" });
  }
});

/**
 * PUT /api/orders/:id - Atualizar status do pedido
 */
router.put("/orders/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user?.id;
    const orderId = parseInt(req.params.id);
    const { status } = req.body;

    if (!userId) {
      return res.status(401).json({ error: "Não autenticado" });
    }

    const database = await getDb();
    if (!database) {
      return res.status(500).json({ error: "Banco de dados indisponível" });
    }

    // Verificar se o pedido pertence ao usuário
    const order = await database
      .select()
      .from(orders)
      .where(and(eq(orders.id, orderId), eq(orders.userId, userId)));

    if (!order || order.length === 0) {
      return res.status(404).json({ error: "Pedido não encontrado" });
    }

    // Atualizar status
    await database
      .update(orders)
      .set({ status: status as any })
      .where(eq(orders.id, orderId));

    res.json({ success: true, status });
  } catch (error) {
    console.error("[API] Erro ao atualizar pedido:", error);
    res.status(500).json({ error: "Erro ao atualizar pedido" });
  }
});

export default router;
