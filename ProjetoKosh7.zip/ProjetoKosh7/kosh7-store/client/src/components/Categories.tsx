import { ArrowRight } from 'lucide-react';

export default function Categories() {
  const categories = [
    {
      title: 'Call Of Duty',
      description: 'Veja os itens disponíveis desta categoria.',
      icon: '🎮',
    },
    {
      title: 'Serviços | Call Of Duty',
      description: 'Veja os itens disponíveis desta categoria.',
      icon: '⚙️',
    },
    {
      title: 'Arc Raiders',
      description: 'Veja os itens disponíveis desta categoria.',
      icon: '🎯',
    },
    {
      title: 'Assinaturas',
      description: 'Veja os itens disponíveis desta categoria.',
      icon: '📦',
    },
    {
      title: 'Battlefield 6',
      description: 'Veja os itens disponíveis desta categoria.',
      icon: '💥',
    },
    {
      title: 'FreeFire',
      description: 'Veja os itens disponíveis desta categoria.',
      icon: '🔥',
    },
  ];

  return (
    <section className="py-20">
      <div className="container">
        <div className="mb-12">
          <h2 className="text-white mb-2">Categorias populares</h2>
          <div className="h-1 w-32 bg-white/20"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category, index) => (
              <div
              key={index}
              className="group"
            >
              <div className="flex items-start gap-4">
                <div className="text-4xl">{category.icon}</div>
                <div className="flex-1">
                  <h3 className="text-white font-bold mb-2">{category.title}</h3>
                  <p className="text-white/60 text-sm mb-4">{category.description}</p>
                  <button className="inline-flex items-center gap-2 text-white font-semibold hover:gap-3 transition-all">
                    Ver produtos
                    <ArrowRight size={18} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
