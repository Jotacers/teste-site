import { useAuth } from "@/_core/hooks/useAuth";
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Features from '@/components/Features';
import Products from '@/components/Products';
import FAQ from '@/components/FAQ';
import Footer from '@/components/Footer';

/**
 * Design Philosophy: Minimalismo Zen com Contraste Dramático
 * - Fundo preto profundo com elementos brancos puros
 * - Espaço negativo generoso como elemento ativo
 * - Yin-yang animado como elemento central
 * - Tipografia elegante (Playfair Display + Lato)
 * - Transições suaves que reforçam a filosofia zen
 */
export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <Hero />
      <Features />
      <Products />
      <FAQ />
      <Footer />
    </div>
  );
}
