import { useState, useEffect } from 'react';
import { ShoppingCart } from 'lucide-react';
import { trpc } from '@/lib/trpc';

export default function Products() {
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [filteredProducts, setFilteredProducts] = useState<any[]>([]);

  const { data: products } = trpc.products.list.useQuery();
  const { data: categories } = trpc.categories.list.useQuery();
  const { data: cart } = trpc.cart.get.useQuery();
  const updateCart = trpc.cart.update.useMutation();

  useEffect(() => {
    if (!products) return;
    
    if (selectedCategory) {
      setFilteredProducts(products.filter(p => p.categoryId === selectedCategory));
    } else {
      setFilteredProducts(products);
    }
  }, [products, selectedCategory]);

  const handleAddToCart = async (productId: number) => {
    if (!cart) {
      await updateCart.mutateAsync({
        items: [{ productId, quantity: 1 }],
      });
    } else {
      const existingItem = cart.items.find((item: any) => item.productId === productId);
      const newItems = existingItem
        ? cart.items.map((item: any) =>
            item.productId === productId
              ? { ...item, quantity: item.quantity + 1 }
              : item
          )
        : [...cart.items, { productId, quantity: 1 }];
      
      await updateCart.mutateAsync({ items: newItems });
    }
  };

  return (
    <section className="py-20">
      <div className="container">
        <div className="mb-12 text-center">
          <h2 className="text-white mb-2 text-4xl font-bold">Nossos Produtos</h2>
          <p className="text-white/60">Explore nossa seleção de produtos de qualidade</p>
        </div>

        {/* Filtros de Categorias */}
        <div className="mb-12 flex flex-wrap gap-4 justify-center">
          <button
            onClick={() => setSelectedCategory(null)}
            className={`px-6 py-2 rounded-full font-semibold transition-colors ${
              selectedCategory === null
                ? 'bg-white text-black'
                : 'bg-white/10 text-white hover:bg-white/20 border border-white/20'
            }`}
          >
            Todos
          </button>
          {categories?.map((category: any) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-6 py-2 rounded-full font-semibold transition-colors ${
                selectedCategory === category.id
                  ? 'bg-white text-black'
                  : 'bg-white/10 text-white hover:bg-white/20 border border-white/20'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Grid de Produtos */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product: any) => (
            <div
              key={product.id}
              className="bg-white/5 border border-white/20 rounded-lg overflow-hidden hover:border-white/40 transition-all hover:bg-white/10"
            >
              {product.image && (
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover"
                />
              )}
              <div className="p-4">
                <h3 className="text-white font-semibold text-lg mb-2">{product.name}</h3>
                <p className="text-white/60 text-sm mb-4 line-clamp-2">{product.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-white font-bold text-xl">
                    R$ {parseFloat(product.price).toFixed(2)}
                  </span>
                  <button
                    onClick={() => handleAddToCart(product.id)}
                    className="bg-white text-black p-2 rounded hover:bg-white/90 transition-colors"
                  >
                    <ShoppingCart size={18} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-white/60">Nenhum produto encontrado nesta categoria.</p>
          </div>
        )}
      </div>
    </section>
  );
}
