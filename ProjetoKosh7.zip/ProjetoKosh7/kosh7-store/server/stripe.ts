import Stripe from "stripe";
import { ENV } from "./_core/env";
import * as db from "./db";
import type { Order } from "../drizzle/schema";

const stripe = new Stripe(ENV.stripeSecretKey, {
  apiVersion: "2026-01-28.clover",
});

/**
 * Criar sessão de checkout do Stripe
 */
export async function createCheckoutSession(
  userId: number,
  email: string,
  items: Array<{ productId: number; quantity: number; price: string }>,
  totalAmount: string,
  origin: string
): Promise<{ sessionId: string; url: string }> {
  const lineItems = items.map((item) => ({
    price_data: {
      currency: "brl",
      unit_amount: Math.round(parseFloat(item.price) * 100), // Converter para centavos
      product_data: {
        name: `Produto ${item.productId}`,
      },
    },
    quantity: item.quantity,
  }));

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card", "boleto"],
    line_items: lineItems,
    mode: "payment",
    success_url: `${origin}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${origin}/checkout/cancel`,
    customer_email: email,
    client_reference_id: userId.toString(),
    metadata: {
      userId: userId.toString(),
      email,
    },
  });

  if (!session.url) {
    throw new Error("Falha ao criar sessão de checkout");
  }

  return {
    sessionId: session.id,
    url: session.url,
  };
}

/**
 * Recuperar sessão de checkout
 */
export async function getCheckoutSession(sessionId: string) {
  return await stripe.checkout.sessions.retrieve(sessionId);
}

/**
 * Criar pagamento com PIX
 */
export async function createPixPayment(
  userId: number,
  email: string,
  totalAmount: string,
  description: string
): Promise<{ clientSecret: string; paymentIntentId: string }> {
  const paymentIntent = await stripe.paymentIntents.create({
    amount: Math.round(parseFloat(totalAmount) * 100), // Converter para centavos
    currency: "brl",
    payment_method_types: ["boleto"],
    description,
    metadata: {
      userId: userId.toString(),
      email,
    },
  });

  return {
    clientSecret: paymentIntent.client_secret || "",
    paymentIntentId: paymentIntent.id,
  };
}

/**
 * Recuperar payment intent
 */
export async function getPaymentIntent(paymentIntentId: string) {
  return await stripe.paymentIntents.retrieve(paymentIntentId);
}

/**
 * Confirmar pagamento
 */
export async function confirmPayment(paymentIntentId: string, paymentMethodId: string) {
  return await stripe.paymentIntents.confirm(paymentIntentId, {
    payment_method: paymentMethodId,
  });
}

/**
 * Processar webhook do Stripe
 */
export async function processWebhook(
  body: string,
  signature: string
): Promise<{ orderId?: number; status: string }> {
  let event;

  try {
    event = stripe.webhooks.constructEvent(body, signature, ENV.stripeWebhookSecret);
  } catch (err) {
    throw new Error(`Webhook signature verification failed: ${err}`);
  }

  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object as Stripe.Checkout.Session;
      const userId = parseInt(session.client_reference_id || "0");

      if (!userId) {
        throw new Error("User ID not found in session");
      }

      // Atualizar pedido como completo
      // Aqui você buscaria o pedido pelo sessionId e atualizaria seu status
      console.log(`[Stripe] Checkout session completed for user ${userId}`);

      return { status: "completed" };
    }

    case "payment_intent.succeeded": {
      const paymentIntent = event.data.object as Stripe.PaymentIntent;
      const userId = paymentIntent.metadata?.userId;

      if (!userId) {
        throw new Error("User ID not found in payment intent");
      }

      console.log(`[Stripe] Payment succeeded for user ${userId}`);

      return { status: "succeeded" };
    }

    case "payment_intent.payment_failed": {
      const paymentIntent = event.data.object as Stripe.PaymentIntent;
      const userId = paymentIntent.metadata?.userId;

      console.log(`[Stripe] Payment failed for user ${userId}`);

      return { status: "failed" };
    }

    default:
      return { status: "unhandled" };
  }
}

/**
 * Reembolsar pagamento
 */
export async function refundPayment(paymentIntentId: string, amount?: number) {
  return await stripe.refunds.create({
    payment_intent: paymentIntentId,
    amount: amount ? Math.round(amount * 100) : undefined,
  });
}

/**
 * Obter lista de métodos de pagamento
 */
export async function getPaymentMethods(customerId: string) {
  return await stripe.paymentMethods.list({
    customer: customerId,
    type: "card",
  });
}
