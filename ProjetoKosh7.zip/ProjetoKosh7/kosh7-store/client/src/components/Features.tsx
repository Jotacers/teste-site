import { Zap, Shield, Headphones } from 'lucide-react';

export default function Features() {
  const features = [
    {
      icon: Zap,
      title: 'Envio imediato',
      description: 'Receba pelo pacote que comprou em poucos segundos após a confirmação do pagamento.',
    },
    {
      icon: Headphones,
      title: 'Suporte eficiente',
      description: 'Em caso de dúvidas, entre em contato com o nosso suporte clicando em Suporte no topo da página.',
    },
    {
      icon: Shield,
      title: 'Compra segura',
      description: 'Seus dados são criptografados de ponta-a-ponta e processados pelo método de pagamento escolhido.',
    },
  ];

  return (
    <section className="py-20">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div key={index} className="flex flex-col gap-4">
                <div className="w-12 h-12 rounded-lg border border-white/30 flex items-center justify-center">
                  <Icon size={24} className="text-white" />
                </div>
                <h3 className="text-white text-xl font-bold">{feature.title}</h3>
                <p className="text-white/70">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
