# Brainstorming de Design - Kosh7 Store

## Contexto
Criar um site de loja de software e serviços para jogos, inspirado na Nexus Corporation, com esquema de cores **preto e branco** e um símbolo **Yin-yang animado** que gira 360 graus.

---

## Ideia 1: Minimalismo Zen com Contraste Dramático
**Probabilidade: 0.08**

**Design Movement:** Minimalismo Zen + Contraste Dramático Moderno

**Core Principles:**
- Espaço negativo generoso como elemento de design ativo
- Contraste máximo entre preto e branco para legibilidade e impacto
- Simetria e equilíbrio visual inspirados na filosofia Yin-yang
- Tipografia limpa e hierarquia clara

**Color Philosophy:**
- Fundo preto profundo (#0a0a0a) como base meditativa
- Branco puro (#ffffff) para texto e elementos principais
- Cinzas sutis (20-30% de opacidade) para elementos secundários
- Sem cores vibrantes—apenas variações de preto/branco/cinza
- Intenção emocional: sofisticação, clareza, foco

**Layout Paradigm:**
- Seções alternadas: fundo preto com conteúdo branco, depois invertido
- Uso de diagonal e assimetria controlada para dinamismo
- Grid invisível com alinhamento preciso
- Espaçamento generoso entre seções (gap de 80-120px)

**Signature Elements:**
1. Yin-yang animado como hero central (gira 360° + retorna)
2. Linhas horizontais sutis como divisores entre seções
3. Cards com borda branca fina em fundo preto

**Interaction Philosophy:**
- Transições suaves (300-400ms) entre estados
- Hover effects minimalistas: mudança de opacidade ou escala leve
- Animações que reforçam a filosofia Zen (fluidas, não abruptas)

**Animation Guidelines:**
- Yin-yang: rotação contínua 360° em 4s, pausa 1s, retorna ao ponto fixo em 2s
- Elementos ao scroll: fade-in suave com movimento vertical leve
- Botões: escala 1.05 ao hover, sombra sutil ao clicar

**Typography System:**
- Display: Playfair Display Bold (títulos principais)
- Body: Lato Regular (corpo de texto)
- Accent: Lato Bold (destaques)
- Hierarquia: 48px → 32px → 24px → 16px → 14px

---

## Ideia 2: Cyberpunk Noir com Efeitos Neon
**Probabilidade: 0.07**

**Design Movement:** Cyberpunk Noir + Efeitos Neon Sutis

**Core Principles:**
- Atmosfera escura e futurista com toques de neon branco
- Efeitos de glow e blur para criar profundidade
- Tipografia ousada e geométrica
- Sensação de movimento e energia

**Color Philosophy:**
- Fundo preto com gradiente sutil (preto puro a cinza muito escuro)
- Branco com glow effect (text-shadow com blur)
- Acentos em cinza claro para elementos secundários
- Intenção emocional: futurismo, energia, sofisticação tech

**Layout Paradigm:**
- Seções com bordas neon brancas/cinzas
- Uso de ângulos e cortes diagonais agressivos
- Elementos flutuantes com sombras de profundidade
- Padrões geométricos sutis como background

**Signature Elements:**
1. Yin-yang com efeito glow ao girar
2. Bordas neon brancas em cards e seções
3. Linhas diagonais como elementos decorativos

**Interaction Philosophy:**
- Transições rápidas e dinâmicas (200-300ms)
- Hover effects com glow aumentado
- Cliques com efeito de pulso (ripple effect)

**Animation Guidelines:**
- Yin-yang: rotação 360° em 3s com glow intenso, retorna em 1.5s
- Elementos: entrada com efeito de "scan" (linha passando)
- Botões: glow aumenta ao hover, pulso ao clicar

**Typography System:**
- Display: Space Mono Bold (títulos futuristas)
- Body: Roboto Regular (corpo legível)
- Accent: Space Mono Bold (destaques tech)
- Hierarquia: 56px → 40px → 28px → 18px → 14px

---

## Ideia 3: Elegância Corporativa Moderna
**Probabilidade: 0.09**

**Design Movement:** Corporativo Moderno + Elegância Minimalista

**Core Principles:**
- Profissionalismo e confiança através de design limpo
- Uso estratégico de espaço em branco
- Tipografia elegante e sofisticada
- Estrutura clara e hierarquia visual forte

**Color Philosophy:**
- Fundo branco ou cinza muito claro (#f5f5f5) como base
- Preto profundo (#1a1a1a) para texto e elementos principais
- Cinzas neutros para elementos secundários
- Intenção emocional: confiança, profissionalismo, clareza

**Layout Paradigm:**
- Grid de 12 colunas com alinhamento preciso
- Seções bem definidas com separadores sutis
- Uso de cards com sombra suave
- Espaçamento consistente e previsível

**Signature Elements:**
1. Yin-yang em posição central com animação suave
2. Cards com sombra minimalista
3. Ícones geométricos simples

**Interaction Philosophy:**
- Transições elegantes (350-450ms)
- Hover effects sutis: mudança de cor ou sombra
- Feedback visual claro mas discreto

**Animation Guidelines:**
- Yin-yang: rotação suave 360° em 5s, pausa 2s, retorna em 2.5s
- Elementos: fade-in ao scroll com movimento suave
- Botões: mudança de cor ao hover, sombra ao clicar

**Typography System:**
- Display: Montserrat Bold (títulos profissionais)
- Body: Open Sans Regular (corpo legível)
- Accent: Montserrat SemiBold (destaques)
- Hierarquia: 48px → 36px → 28px → 16px → 14px

---

## Decisão Final
**Abordagem Escolhida: Minimalismo Zen com Contraste Dramático**

Esta abordagem oferece o melhor equilíbrio entre:
- A filosofia Yin-yang se alinha naturalmente com o design zen
- Contraste máximo preto/branco garante legibilidade e impacto visual
- Simplicidade permite foco no conteúdo e na animação do Yin-yang
- Sofisticação sem excessos mantém o site profissional e moderno
