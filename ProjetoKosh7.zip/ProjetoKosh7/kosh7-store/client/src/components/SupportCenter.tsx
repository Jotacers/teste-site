import { MessageCircle } from 'lucide-react';

export default function SupportCenter() {
  return (
    <section className="py-20">
      <div className="container">
        <div className="max-w-2xl mx-auto text-center">
          <div className="mb-8">
            <h2 className="text-white mb-4">Central de Atendimento</h2>
            <p className="text-white/60">
              Conecte-se conosco no Discord para suporte 24/7 e interaja com nossa comunidade
            </p>
          </div>

          <a
            href="https://discord.gg/waD9MFdD"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 bg-white text-black px-8 py-4 rounded-full font-semibold hover:bg-white/90 transition-colors"
          >
            <MessageCircle size={24} />
            <span>Entrar no Discord</span>
          </a>
        </div>
      </div>
    </section>
  );
}
